# NEXUS release shrinker rules
